package uk.co.turkltd.locationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    String masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC);

    String sharedPreferences = EncryptedSharedPreferences.create(
            "serverURL",
            masterKeyAlias,
            applicationContext,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    );

    SharedPreferences.Editor editor = sharedPreferences.edit();

    String serverURL;
    EditText serverInput;
    TextView displayURL;
    Button submitButton;
    Button locationButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        serverInput = findViewById(R.id.serverInput);

        submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                serverURL = serverInput.getText().toString();

                editor.putString("URL:", serverURL);
                editor.apply();
            }
        });

        locationButton = findViewById(R.id.locationButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){

            }
        });

        displayURL = findViewById(R.id.displayURL);
        displayURL.setText(serverURL);
    }
}